#ifndef HASH_H
#define HASH_H

#include "types.h"
#include "board.h"

uint64 hash(board_t *board);


#endif
