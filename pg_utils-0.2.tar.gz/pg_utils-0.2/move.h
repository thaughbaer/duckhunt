#ifndef MOVE_H
#define MOVE_H

int move_from_string(char move_s[6], uint16 *move);
int move_to_string(char move_s[6], uint16 move);

#endif
