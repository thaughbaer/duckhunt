The scripts in this directory are taken directly from the
pod documentation of Chess::PGN::EPD and are here to
save you a bit of cut and paste.

readme.txt
sample.pgn
sample1.pl
sample2.pl
sample3.pl

The .pgn file is useful as input to sample1 and sample3--- sample2 is stand-alone.